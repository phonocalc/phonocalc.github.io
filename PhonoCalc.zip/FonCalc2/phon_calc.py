#
# This is super awesome script for my Phonotactic Calculator for (not only) the Czech language.
# Made by Jarcec for his sister.
#
import logging
import argparse
import math
from corpy.phonetics import cs

#
# Constants
#
DATABASE_NAME = 'syn2015_word_utf8.tsv'

#
# Global configuration
#
logger = logging.getLogger(__name__)


#
# Helper classes
#

class Word:
    """Word and it's frequency in language."""
    def __init__(self, word, frequency, transcribe, reverse):
        self.word = word.lower()
        if transcribe:
            self.transcribe = cs.transcribe(self.word, alphabet='IPA')[0]
            if reverse:
                self.transcribe = self.transcribe[::-1]
        else:
            self.transcribe = None

        if reverse:
            self.word = self.word[::-1]
        self.frequency = int(frequency)
        self.log10_frequency = math.log(self.frequency, 10)

    def ngram_on_position(self, position, bigram, ngram=2):
        """Return true if given ngram is on given position."""
        return self._ngram(position, ngram) == bigram

    def _ngram(self, position, ngram=2):
        """Internal method to return ngram on given position (either normal or transcribed)."""
        return self.transcribe[position:position+ngram] if self.transcribe else self.word[position:position+ngram]


class WordDatabase:
    """Whole database of words in the original format with many different columns."""
    def __init__(self, database_name, word, frequency, transcribe=False, reverse=False):
        self.words = []

        logger.info(f"Loading database from {database_name}")
        # Load the database from file
        with open(database_name) as f:
            content = f.readlines()

            for line in content:
                if len(line.strip()) > 0:
                    columns = line.split("\t")
                    try:
                        self.words.append(Word(columns[word], columns[frequency], transcribe, reverse))
                    except ValueError as e:
                        logger.error(f"Can't transcribe word {columns[word]}: {e}")

        logger.info(f"Loaded {len(self.words)} words from {database_name}")

    def dump_transcribe(self):
        """Dump database of words with their phonetic transcription."""
        for word in self.words:
            print(f"{word.word}: {word.transcribe}")


class Main:
    """Main execution container."""
    def __init__(self, args):
        self.args = args

    def validate_args(self):
        """Validate that right set of arguments is used together."""
        if args.transcribe_database:
            if args.words or args.transcribe or args.words_file:
                raise Exception('Incompatible set of arguments entered, do -h to see which ones :)')

    def execute(self):
        """Execute the correct action based on the specified args."""
        if self.args.transcribe_database:
            self.transcribe_database()
        else:
            self.calculate()

    def transcribe_database(self):
        """Print out database of words with their phonetic transcription."""
        database = WordDatabase(
            self.args.database if self.args.database else DATABASE_NAME,
            int(self.args.database_word_index),
            int(self.args.database_frequency_index),
            True,
            self.args.reverse
        )
        database.dump_transcribe()

    def calculate(self):
        """Calculate the phonotactic probability."""
        # Create database of words
        database = WordDatabase(
            self.args.database if self.args.database else DATABASE_NAME,
            int(self.args.database_word_index),
            int(self.args.database_frequency_index),
            self.args.transcribe,
            self.args.reverse
        )

        # All words entered on the command line
        words = self.args.words if self.args.words else []

        # Read additional words from a file
        if self.args.words_file:
            f = open(self.args.words_file, "r")
            for line in f.readlines():
                words.append(line.strip())

        # Let's go over each word and calculate the outcome
        for word in words:
            self._calculate_word(database, word)

    def _calculate_word(self, database, word):
        # Iterate over bi-grams
        i = 0
        ngram_size = int(self.args.ngram)
        phonprob = 0

        # Calculate working word based on transcribe/reverse state
        working_word = cs.transcribe(word, alphabet='IPA')[0] if self.args.transcribe else word
        if self.args.reverse:
            working_word = working_word[::-1]
        while i < len(working_word) - ngram_size + 1:
            # Generate ngram from this index
            ngram = working_word[i:i + ngram_size]
            logger.info(f"Generated ngram {ngram} for position {i}")

            # Now let's find the words that have ngram on given position
            matching_frequency_sum = 0
            matches_count = 0
            for w in database.words:
                if w.ngram_on_position(i, ngram, ngram_size):
                    logger.debug(f"Found matching word {w.word}")
                    matching_frequency_sum = matching_frequency_sum + w.log10_frequency
                    matches_count = matches_count + 1

            all_frequency_sum = 0
            all_count = 0
            for w in database.words:
                if len(w.word) >= i + ngram_size:
                    all_frequency_sum = all_frequency_sum + w.log10_frequency
                    all_count = all_count + 1

            logger.info(
                f"Found {matches_count} matches for ngram {ngram} ({all_count}),  matching_frequency_sum={matching_frequency_sum}, all_frequency_sum={all_frequency_sum}")

            phonprob = phonprob + (matching_frequency_sum / all_frequency_sum)

            # Prepare for next iteration
            i = i + 1

        # And we're almost done
        logger.info(f"Generated {i} ngrams")
        phonprob = phonprob / i
        print(f"{word}: {phonprob}")


#
# Main script
#

# Parse user input
parser = argparse.ArgumentParser(description='Phonotactic Calculator')
parser.add_argument('--transcribe-database', dest='transcribe_database', action='store_true', help='Transcribe loaded database')
parser.add_argument('--word', dest='words', action='append', help='Word that needs to be calculated')
parser.add_argument('--words-file', dest='words_file', action='store', help='Read words from a file - one line per word')
parser.add_argument('--verbose', dest='verbose', action='store_true', help='Log more details while working')
parser.add_argument('--database', dest='database', help=f'Filename of the database, defaults to {DATABASE_NAME}')
parser.add_argument('--database-word-index', dest='database_word_index', default='1', help=f'Index of the column containing the word')
parser.add_argument('--database-frequency-index', dest='database_frequency_index', default='2', help=f'Index of the column containing the word frequency')
parser.add_argument('--transcribe', dest='transcribe', action='store_true', help='Use phonetic transcribe as additional calculation point')
parser.add_argument('--reverse', dest='reverse', action='store_true', help='Generate Phonotactic calculation will be calculated reading the words in reversed order.')
parser.add_argument('--ngram', dest='ngram', action='store', default='2', help='How large ngram should be used')
args = parser.parse_args()

# Configure logging per the arguments
log_level = logging.DEBUG if args.verbose else logging.INFO
logging.basicConfig(level=log_level)

main = Main(args)
main.validate_args()

main.execute()
